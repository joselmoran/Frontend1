import React from "react";
import logo from '../logo.svg';
import { useHistory } from "react-router-dom";
import * as actions from "../store/actions";
import { useDispatch, useSelector } from "react-redux";
import {useInputHook} from "../my-hooks/input-hook";

function Rides() {
  
  const history = useHistory();
  const dispatch = useDispatch();

  // Input-hook fields.
  const {value: rideId, setValue: setRideId, bind: bindRideId, reset: resetRideId} = useInputHook('');
  const {value: firstPoint, setValue: setFirstPoint, bind: bindFirstPoint, reset: resetFirstPoint} = useInputHook('');
  const {value: targetPoint, setValue: setTargetPoint, bind: bindTargetPoint, reset: resetTargetPoint} = useInputHook('');
  const {value: username, setValue: setUsername, bind: bindUsername, reset: resetUsername} = useInputHook('');
  const {value: driverId, setValue: setDriverId, bind: bindDriverId, reset: resetDriverId} = useInputHook('');
  const {value: time, setValue: setTime, bind: bindTime, reset: resetTime} = useInputHook('');

  const handleSubmitRider = e => {
    // Send fields to the actions.
    const data = {rideId,firstPoint,targetPoint,username,driverId,time};
    dispatch(actions.postRides(data));


    // Reset fields.
    resetRideId();
    resetFirstPoint();
    resetTargetPoint();
    resetUsername();
    resetDriverId();
    resetTime();
    e.preventDefault();
  }


  return (
    <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
            
          <p>
          React Rides Form:
          </p>  

          <form onSubmit={handleSubmitRider}>
            <input placeholder="rideId" type="text" {...bindRideId}></input><br></br>
            <input placeholder="firstPoint" type="text" {...bindFirstPoint}></input><br></br>
            <input placeholder="targetPoint" type="text" {...bindTargetPoint}></input><br></br>
            <input placeholder="username" type="text" {...bindUsername}></input><br></br>
            <input placeholder="driverId" type="text" {...bindDriverId}></input><br></br>
            <input placeholder="time" type="text" {...bindTime}></input><br></br>

            <input type="submit" value="enviar"></input>
          </form>

          <br></br>
          <button value="Home" onClick={() => history.push('')}>
            Home
          </button>


        </header>
    </div>
  );
}

export default Rides;


