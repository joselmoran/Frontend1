import React from "react";
import logo from '../logo.svg';
import { useHistory } from "react-router-dom";
import * as actions from "../store/actions";
import { useDispatch, useSelector } from "react-redux";
import {useInputHook} from "../my-hooks/input-hook";

function Drivers() {

  const history = useHistory();
  const dispatch = useDispatch();

  // Input-hook fields.
  const {value: driverId, setValue: setDriverId, bind: bindDriverId, reset: resetDriverID} = useInputHook('');
  const {value: username, setValue: setUsername, bind: bindUsername, reset: resetUsername} = useInputHook('');
  const {value: firstName, setValue: setFirstName, bind: bindFirstName, reset: resetFirstName} = useInputHook('');
  const {value: lastname, setValue: setLastname, bind: bindLastname, reset: resetLastname} = useInputHook('');
  const {value: age, setValue: setAge, bind: bindAge, reset: resetAge} = useInputHook(0);
  const {value: phone, setValue: setPhone, bind: bindPhone, reset: resetPhone} = useInputHook('');

  const handleSubmitDriver = e => {
    // Send fields to the actions.
    const data = {driverId,username,firstName,lastname,age,phone};
    dispatch(actions.postDrivers(data));


    // Reset fields.
    resetDriverID();
    resetUsername();
    resetFirstName();
    resetLastname();
    resetAge();
    resetPhone();
    e.preventDefault();
  }


  return (
    <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
            
          <p>
          React Driver Form:
          </p>  

          <form onSubmit={handleSubmitDriver}>
            <input placeholder="driverId" type="text" {...bindDriverId}></input><br></br>
            <input placeholder="username" type="text" {...bindUsername}></input><br></br>
            <input placeholder="firstName" type="text" {...bindFirstName}></input><br></br>
            <input placeholder="lastname" type="number" {...bindLastname}></input><br></br>
            <input placeholder="age" type="text" {...bindAge}></input><br></br>
            <input placeholder="phone" type="text" {...bindPhone}></input><br></br>

            <input type="submit" value="enviar"></input>
          </form>

          <br></br>
          <button value="Home" onClick={() => history.push('')}>
            Home
          </button>


        </header>
    </div>
  );
}

export default Drivers;

