import React, {useEffect, useState} from "react";
import logo from '../logo.svg';
import { useHistory } from "react-router-dom";
import * as actions from "../store/actions";
import { useDispatch, useSelector } from "react-redux";
import {useInputHook} from "../my-hooks/input-hook";

function Customers() {
  
  const history = useHistory();
  const dispatch = useDispatch();

  const customers = useSelector(store => store.customers);

  // Input-hook fields.
  const {value: customerId, setValue: setCustomerId, bind: bindCustomerId, reset: resetCustomerId} = useInputHook('');
  const {value: username, setValue: setUsername, bind: bindUsername, reset: resetUsername} = useInputHook('');
  const {value: firstname, setValue: setFirstname, bind: bindFirstname, reset: resetFirstname} = useInputHook('');
  const {value: lastname, setValue: setLastname, bind: bindLastname, reset: resetLastname} = useInputHook('');
  const {value: email, setValue: setEmail, bind: bindEmail, reset: resetEmail} = useInputHook('');
  const {value: phone, setValue: setPhone, bind: bindPhone, reset: resetPhone} = useInputHook('');

  const handleSubmitCustomer = e => {
    // Send fields to the actions.
    const data = {customerId,username,firstname,lastname,email,phone};
    // console.log(data);
    dispatch(actions.postCustomers(data));

    // Reset fields.
    resetCustomerId();
    resetUsername();
    resetFirstname();
    resetLastname();
    resetEmail();
    resetPhone();
    e.preventDefault();
  }

  useEffect(() => {
    dispatch(actions.getCustomers())
  }, [dispatch]);//Actualiza todo lo que esta pendiente en el redux.

  const customerDetails = (customer, customerId) => {
    console.log('Customer details:');
    console.log(customer);
    // console.log(customerId);
  }

  const deleteCustomerById = (customerId) => {
    console.log(customerId);
  }


  return (
    <div className="App">
        <header className="App-header">
          {/* <img src={logo} className="App-logo" alt="logo" /> */}

          <table>
            <tbody>
            <tr>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
            </tr>
            </tbody>
          </table>


            
          <p>
          Add new Customer:
          </p>  

          <form onSubmit={handleSubmitCustomer}>
            <input placeholder="customerId" type="text" {...bindCustomerId}></input><br></br>
            <input placeholder="username" type="text" {...bindUsername}></input><br></br>
            <input placeholder="firstname" type="text" {...bindFirstname}></input><br></br>
            <input placeholder="lastname" type="text" {...bindLastname}></input><br></br>
            <input placeholder="email" type="text" {...bindEmail}></input><br></br>
            <input placeholder="phone" type="text" {...bindPhone}></input><br></br>

            <input type="submit" value="Add Customer"></input>
          </form>


          <br></br>
          <button value="Home" onClick={() => history.push('')}>
            Home
          </button>

          <p>
            All Customers:
          </p> 
          {/* {customers && customers.length > 0 && customers.map(customer => (
            <tr>
              <td>{customer.firstname}</td>
              <td>{customer.lastname}</td>
              <td><button>Details</button></td>
            </tr>
          ))} */}

        

          {/* <table class="demo">
            <caption>Table 1</caption>
            <thead>
            <tr>
              <th>First Name</th>
              <th>Last Name</th>
              <th>Details</th>
            </tr>
            </thead>
            <tbody>
            <tr>
              <td>Carlos</td>
              <td>Gutierrez</td>
              <td><button>Details</button></td>
            </tr>
            <tr>
              <td>Enrique</td>
              <td>Mora</td>
              <td><button>Details</button></td>
            </tr>
            </tbody>
          </table> */}

          
            <table class="demo">
              <caption>Table 1</caption>
              <thead>
              <tr>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Details</th>
                <th>Delete</th>
              </tr>
              </thead>
              <tbody>
              {customers && customers.length > 0 && customers.map(customer => (
                <tr>
                  <td>{customer.firstname}</td>
                  <td>{customer.lastname}</td>
                  <td><button onClick={() => customerDetails(customer,customer._id)}>Details</button></td>
                  <td><button onClick={() => deleteCustomerById(customer._id)}>Delete</button></td>
                </tr>
                ))
              }
              </tbody>
            </table> 
          

          


        </header>
    </div>
  );
}

export default Customers;


