import React from "react";
import { useHistory } from "react-router-dom";
import logo from '../logo.svg';
import * as actions from '../store/actions';
import {useDispatch, useSelector} from 'react-redux';

function Home() {

  const history = useHistory();
  

  return (
    <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />

        <h2>Home</h2>

      <br/>
      <button type="button" onClick={() => history.push('customers')}>
        Show all Customers
      </button><br/>


      <button type="button" onClick={() => history.push('cars')}>
        Show all Cars
      </button><br/>

      <button type="button" onClick={() => history.push('drivers')}>
        Show all Drivers
      </button><br/>

      <button type="button" onClick={() => history.push('rides')}>
        Show all Rides
      </button><br/>
    </header>
  </div>
    
      


    
  );
}

export default Home;