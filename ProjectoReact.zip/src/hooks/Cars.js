import React from "react";
import logo from '../logo.svg';
import { useHistory } from "react-router-dom";
import * as actions from "../store/actions";
import { useDispatch, useSelector } from "react-redux";
import {useInputHook} from "../my-hooks/input-hook";

function Cars() {

  const history = useHistory();
  const dispatch = useDispatch();

  // Input-hook fields.
  const {value: carId, setValue: setCarId, bind: bindCarId, reset: resetCarId} = useInputHook('');
  const {value: plateNumber, setValue: setPlateNumber, bind: bindPlateNumber, reset: resetPlateNumber} = useInputHook('');
  const {value: motorSerial, setValue: setMotorSerial, bind: bindMotorSerial, reset: resetMotorSerial} = useInputHook('');
  const {value: chassisSerial, setValue: setChassisSerial, bind: bindChassisSerial, reset: resetChassisSerial} = useInputHook('');
  const {value: color, setValue: setColor, bind: bindColor, reset: resetColor} = useInputHook('');
  const {value: model, setValue: setModel, bind: bindModel, reset: resetModel} = useInputHook('');

  const handleSubmitCar = e => {
    // Send fields to the actions.
    const data = {carId,plateNumber,motorSerial,chassisSerial,color,model};
    dispatch(actions.postCars(data));

    // Reset fields.
    resetCarId();
    resetPlateNumber();
    resetMotorSerial();
    resetChassisSerial();
    resetColor();
    resetModel();
    e.preventDefault();
  }


  return (
    <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
            
          <p>
          React Car Form:
          </p>  

          <form onSubmit={handleSubmitCar}>
            <input placeholder="carId" type="text" {...bindCarId}></input><br></br>
            <input placeholder="plateNumber" type="text" {...bindPlateNumber}></input><br></br>
            <input placeholder="motorSerial" type="text" {...bindMotorSerial}></input><br></br>
            <input placeholder="chassisSerial" type="text" {...bindChassisSerial}></input><br></br>
            <input placeholder="color" type="text" {...bindColor}></input><br></br>
            <input placeholder="model" type="text" {...bindModel}></input><br></br>

            <input type="submit" value="enviar"></input>
          </form>


          <br></br>
          <button value="Home" onClick={() => history.push('')}>
            Home
          </button>


        </header>
    </div>
  );
}

export default Cars;


