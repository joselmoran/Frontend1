import {POST_CUSTOMERS, POST_CUSTOMERS_ERROR, POST_CARS, POST_CARS_ERROR,
        POST_DRIVERS, POST_DRIVERS_ERROR,POST_RIDES,POST_RIDES_ERROR, GET_CUSTOMERS, GET_CUSTOMERS_ERROR} from './actions';

const initialState = {
  customers: [],
  customerError:'',
  cars: '',
  carError:'',
  drivers: '',
  driverError:'',
  rides: '',
  rideError:'',
  
}

export const reducers = (state = initialState, action) => {
    switch (action.type) {
      case GET_CUSTOMERS:
        return {
          ...state,
          customers: action.payload.data
        }
      case GET_CUSTOMERS_ERROR:
        return {
          ...state,
          customerError: action.payload.error
        }
      case POST_CUSTOMERS:
        return {
          ...state,
          customer: action.payload.data
        }
      case POST_CUSTOMERS_ERROR:
        return {
          ...state,
          customerError: action.payload.error
        }
      case POST_CARS:
        return {
          ...state,
          car: action.payload.data
        }
      case POST_CARS_ERROR:
        return {
          ...state,
          carError: action.payload.error
        }
      case POST_DRIVERS:
        return {
          ...state,
          driver: action.payload.data
        }
      case POST_DRIVERS_ERROR:
        return {
          ...state,
          driverError: action.payload.error
        }
      case POST_RIDES:
        return {
          ...state,
          ride: action.payload.data
        }
      case POST_RIDES_ERROR:
        return {
          ...state,
          rideError: action.payload.error
        }
      default:
        return state;
    }
  };