import services from '../services/api.services';

export const POST_CUSTOMERS = 'POST_CUSTOMERS';
export const POST_CUSTOMERS_ERROR = 'POST_CUSTOMERS_ERROR';

export const POST_CARS = 'POST_CARS';
export const POST_CARS_ERROR = 'POST_CARS_ERROR';

export const POST_DRIVERS = 'POST_DRIVERS';
export const POST_DRIVERS_ERROR = 'POST_DRIVERS_ERROR';

export const POST_RIDES = 'POST_RIDES';
export const POST_RIDES_ERROR = 'POST_RIDES_ERROR';


// GET
export const GET_CUSTOMERS = 'GET_CUSTOMERS';
export const GET_CUSTOMERS_ERROR = 'GET_CUSTOMERS_ERROR';

/**
 * CUSTOMERS
 */
export const postCustomers = (data) => {
    return dispatch => {
      services.postCustomer(data)
        .then(response  => {
          console.log(response);
          dispatch(postCustomersAsync(response));
        })
        .catch(error => {
          console.log(error);
          dispatch(postCustomersErrorAsync(error));
        });
    }
  }
  
export const postCustomersAsync = (payload) => ({
  type: POST_CUSTOMERS,
  payload: payload
});

export const postCustomersErrorAsync = (error) => ({
  type: POST_CUSTOMERS_ERROR,
  error: error
});


/**
 * CUSTOMERS
 */
export const getCustomers = () => {
  return dispatch => {
    services.getCustomers()
      .then(response => {
        console.log(response);
        dispatch(getCustomersAsync(response));
      })
      .catch(error => {
        console.log(error);
        dispatch(getCustomersErrorAsync(error));
      });
  }
}

export const getCustomersAsync = (payload) => ({
  type: GET_CUSTOMERS,
  payload: payload
});

export const getCustomersErrorAsync = (error) => ({
  type: GET_CUSTOMERS_ERROR,
  error: error
});




/**
 * CARS
 */
export const postCars = (data) => {
    return dispatch => {
      services.postCar(data)
        .then(response  => {
          console.log(response);
          dispatch(postCarsAsync(response));
        })
        .catch(error => {
          console.log(error);
          dispatch(postCarsErrorAsync(error));
        });
    }
  }
  
export const postCarsAsync = (payload) => ({
  type: POST_CARS,
  payload: payload
});

export const postCarsErrorAsync = (error) => ({
  type: POST_CARS_ERROR,
  error: error
});


/**
 * DRIVERS
 */
export const postDrivers = (data) => {
    return dispatch => {
      services.postDriver(data)
        .then(response  => {
          console.log(response);
          dispatch(postDriversAsync(response));
        })
        .catch(error => {
          console.log(error);
          dispatch(postDriversErrorAsync(error));
        });
    }
  }
  
export const postDriversAsync = (payload) => ({
  type: POST_DRIVERS,
  payload: payload
});

export const postDriversErrorAsync = (error) => ({
  type: POST_DRIVERS_ERROR,
  error: error
});

/**
 * RIDES
 */
export const postRides = (data) => {
    return dispatch => {
      services.postRide(data)
        .then(response  => {
          console.log(response);
          dispatch(postRidesAsync(response));
        })
        .catch(error => {
          console.log(error);
          dispatch(postRidesErrorAsync(error));
        });
    }
  }
  
export const postRidesAsync = (payload) => ({
  type: POST_RIDES,
  payload: payload
});

export const postRidesErrorAsync = (error) => ({
  type: POST_RIDES_ERROR,
  error: error
});





