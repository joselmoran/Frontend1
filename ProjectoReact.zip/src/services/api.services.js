import http from './http-commons';

const getCustomers = () => {
  return http.get('/users/customers');
};







const getCars = () => {
  return http.get('/cars');
};

const getDrivers = () => {
  return http.get('/drivers');
};

const getRides = () => {
  return http.get('/rides');
};

const postCustomer = (data) => {
  return http.post('/customers/create', data);
}

const postDriver = (data) => {
  return http.post('/drivers/create', data);
}

const postCar = (data) => {
  return http.post('/cars/create', data);
}

const postRide = (data) => {
  return http.post('/rides/create', data);
}

export default {
    getCustomers,
    getCars,
    getDrivers,
    getRides,
    postCustomer,
    postDriver,
    postCar,
    postRide
}